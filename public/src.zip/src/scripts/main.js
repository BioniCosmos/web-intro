const greeting = document.querySelector('#greeting')
const switchUserButton = document.querySelector('#switch-user')
switchUserButton.addEventListener('click', function () {
  setUserName()
})
const clearButton = document.querySelector('#clear')
clearButton.addEventListener('click', function () {
  greeting.textContent = '你好！'
})
setUserName()

function setUserName() {
  const name = prompt('请输入您的名字：')
  if (name === null || name === '') {
    setUserName()
  } else {
    greeting.textContent = `你好，${name}！`
  }
}
